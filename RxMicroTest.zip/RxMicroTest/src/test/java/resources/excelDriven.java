package resources;
import java.io.IOException;
import java.util.ArrayList;

public class excelDriven {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		
	dataDriven d=new dataDriven();
	ArrayList data=d.getData("productInfo");
	
	System.out.println(data.get(0));
	System.out.println(data.get(1));
	System.out.println(data.get(2));
	
	}

	}


