package rxmicro.cris;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class CrisRxTicketInfo extends CrisProductInfo {

		public static String responseJson;
		
		@Test(testName ="Verify if the success response is returned for CrisTicketInfo")
		public void rxTicketInfoCris() {
			RestAssured.baseURI = prop.getProperty("url");
			System.out.println("rxSessionIdentifier: "+ CrisProductInfo.rxSessionIdentifer);
			log.info(CrisProductInfo.rxSessionIdentifer);
			Response res =

					  given().
					        param("wtn", wtn).
					        param("customerProductId", map.get("PRISM")).
							param("rxSessionIdentifier",CrisProductInfo.rxSessionIdentifer).
				      when().
				             get("rxTicketInfo").
				      then().assertThat().statusCode(200).contentType(ContentType.JSON).
			          extract().response();
			
			System.out.println("Response TicketInfo Json: "+res.asString());
			log.info(res.asString());
			
			responseJson = res.asString();
			log.info("Response rxTicketInfo JSON: "+responseJson);
			
		}
		public String getResponseJson() {
			return responseJson;
		}
		public void setResponseJson(String responseJson) {
			CrisRxTicketInfo.responseJson = responseJson;
		}

	}

