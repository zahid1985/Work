package rxmicro.ensemble;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import resources.*;

public class EnsembleRxOutageInfo extends EnsembleProductInfo {

	public static String responseJson=null;
	
	@Test(testName ="Verify if the success response is returned for ENSEMBLEOutageInfo")
	public void rxOutageInfoEnsemble() {
		RestAssured.baseURI = prop.getProperty("url");
		System.out.println("rxSessionIdentifier: "+responseJson.split("rxSessionIdentifier\":\"")[1].split("\"")[0].trim());
		Response res =

				  given().
				        param("etn", wtn).
				        param("customerProductId", map.get("HSI")).
						param("rxSessionIdentifier", EnsembleProductInfo.rxSessionIdentifer).
			      when().
			             get("rxOutageInfo").
			      then().assertThat().statusCode(200).contentType(ContentType.JSON).
		          extract().response();
		
		System.out.println("Response OutageInfo Json: "+res.asString());
		log.info(res.asString());
		
		responseJson = res.asString();
		log.info("Response OutageInfo JSON: "+responseJson);
		
	}
	public String getResponseJson() {
		return responseJson;
	}
	public void setResponseJson(String responseJson) {
		EnsembleRxOutageInfo.responseJson = responseJson;
	}

}
