package rxmicro.ensemble;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import resources.*;

public class EnsembleRxTicketInfo extends EnsembleProductInfo {

	public static String responseJson=null;
	
	@Test(testName ="Verify if the success response is returned for ENSEMBLETicketInfo")
	public void rxTicketInfoEnsemble() {
		RestAssured.baseURI = prop.getProperty("url");
		System.out.println("rxSessionIdentifier: "+responseJson.split("rxSessionIdentifier\":\"")[1].split("\"")[0].trim());
		Response res =

				  given().
				        param("wtn", wtn).
				        param("customerProductId", map.get("HSI")).
						param("rxSessionIdentifier", responseJson.split("rxSessionIdentifier\":\"")[1].split("\"")[0].trim()).
			      when().
			             get("rxTicketInfo").
			      then().assertThat().statusCode(200).contentType(ContentType.JSON).
		          extract().response();
		
		System.out.println("Response TicketInfo Json: "+res.asString());
		log.info(res.asString());
		
		responseJson = res.asString();
		log.info("Response rxTicketInfo JSON: "+responseJson);
		
	}
	public String getResponseJson() {
		return responseJson;
	}
	public void setResponseJson(String responseJson) {
		EnsembleRxTicketInfo.responseJson = responseJson;
	}

}
