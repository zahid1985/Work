package rxmicro.ensemble;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import resources.*;


public class EnsembleProductInfo {
	
	public static Logger log=LogManager.getLogger(EnsembleProductInfo.class.getName());
	
	public Map<String, String> map = null;
	public static String responseJson=null;
	public static String wtn;
	public 	Properties prop = null;
	public static String rxSessionIdentifer=null;

	
	public void getWTN() throws IOException {
		dataDriven d=new dataDriven();
		ArrayList data=d.getData("productInfo");
		wtn = (String) data.get(1);
	}
	
	@BeforeClass
	public void getResponse() throws IOException {
		prop = new Properties();
		try {
			prop.load(new FileInputStream(new File("environment.properties")));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		getWTN();
		getResponseData();
	}
	
	@Test(testName ="Verify if the success response is returned for ENSEMBLE")
	public void EnsembleProductInformation() throws IOException {
		// CRIS products
		/*
		 * System.out.println(getCustProductIdentifier("IP_DATA"));
		 * System.out.println(getCustProductIdentifier("PAIRBONDED"));
		 * System.out.println(getCustProductIdentifier("DSL"));
		 * System.out.println(getCustProductIdentifier("POTS"));
		 * System.out.println(getCustProductIdentifier("PRISM"));
		 */
		// ENSEMBLE products
		
		System.out.println(getCustProductIdentifier("HSI"));
		System.out.println(getCustProductIdentifier("CTL_PRISM"));
		System.out.println(getCustProductIdentifier("VOICE"));
		
		log.info(getCustProductIdentifier("HSI"));
		log.info(getCustProductIdentifier("CTL_PRISM"));
		log.info(getCustProductIdentifier("VOICE"));

	}

	public String getCustProductIdentifier(String highLevelProductName) {
		if (map.get(highLevelProductName) != null)
			return highLevelProductName + " has customerProductIdentifier: " + map.get(highLevelProductName);
	else
		return "CustomerProductId for " + highLevelProductName + " was not found!!";
	}

	public Map<String, String> extractProducts(String responseJson) {

		map = new HashMap<>();
		String cps = "highLevelProduct\":\"";
		String[] temp = responseJson.split(cps);
		/*
		 * String[] hlps = {"HSI", "MISC", "DHP", "ISDN_PRI_ILEC", "PBX_ANALOG_ILEC",
		 * "ATM_CIRCUIT", "POTS Multiline Hunt", "POTS", "VOICE", "VDSL_DATA",
		 * "VOICE_PACK", "ISDN_BRI_ILEC", "CENTREX_CLEC", "DSL", "VDSL_VIDEO", "QHOME",
		 * "FRAME_RELAY", "ISDN_PRI_CLEC", "DIRECTTV", "VM", "QWESTDOTNET_CONTENT",
		 * "PRIVATE_LINE", "PBX_DIGITAL_ILEC", "MR", "IP_DATA", "CTL_PRISM",
		 * "PRISM_PHONEFEATURES", "KEY_ILEC", "DOTNOT_DSL_ATM", "VERIZON_WIRELESS",
		 * "PRISM", "CENTREX_ILEC", "VIRTUAL_RECEPTIONIST", "CTL_BUSINESS_VOIP",
		 * "WEB_HOSTING", "GPON_RF_VIDEO", "WFAC_CIRCUIT", "LMOS_CKT", "PAIR_BONDED",
		 * "MSN_CONTENT", "VMDU", "BUSINESS_VOIP"};
		 */
		String[] cp_split = null;
		String customerProductIdentifier = null;
		if (temp.length > 0) {
			for (int i = 1; i < temp.length; i++) {
				cp_split = temp[i].split("\"");
				customerProductIdentifier = temp[i - 1].split("customerProductIdentifier")[1].split("\"")[2];
				map.put(cp_split[0].trim(), customerProductIdentifier.trim());

			}
		}
		return map;

	}

	public void getResponseData() {
		System.out.println("----For--TN: "+wtn+"----------");
		log.info("WTN used is " +wtn);
		map = null;
		// To define the Host
//		RestAssured.baseURI = "http://rxmicro-test2.kubeodc.corp.intranet/rxmicro/services/";
		RestAssured.baseURI = prop.getProperty("url");
		log.info(prop.getProperty("url"));
		Response res =

				given().param("etn", wtn).// To define the Parameters//4079091141
						when().get("rxProductInfo").then().assertThat().statusCode(200).contentType(ContentType.JSON)
						.and().body("serviceLines[0].serviceTnOrCktId", equalTo(wtn)).
               
						// To grab the response

						extract().response();
		log.info("Service used is rxProductInfo");
		responseJson = res.asString();
		log.info("Response ProductInfo JSON: "+responseJson);
	   
		
		System.out.println("Response ProductInfo JSON: "+responseJson);
		setResponseJson(responseJson);
		map = extractProducts(responseJson);
		System.out.println("Response Map: "+map);
		log.info("Response Map: "+map);
		System.out.println("---------------------------------");
		
		
		// To extract the session id String rxSessionIdentifier 
		  JsonPath js= new JsonPath(responseJson);
		  rxSessionIdentifer = js.get("rxSessionIdentifier");
		  //String a = rxSessionIdentifer.toString();
		  System.out.println("Corresponding RxSessionId is " +rxSessionIdentifer);
		  log.info("Corresponding RxSessionId is " +rxSessionIdentifer);
		  
	
	}

	public static String getRxSessionIdentifer() {
		return rxSessionIdentifer;
	}

	public static void setRxSessionIdentifer(String rxSessionIdentifer) {
		EnsembleProductInfo.rxSessionIdentifer = rxSessionIdentifer;
	}

	
	public String getResponseJson() {
		return responseJson;
	}

	public void setResponseJson(String responseJson) {
		EnsembleProductInfo.responseJson = responseJson;
	}
	
	
	/*
	 * public static void report() {
	 * 
	 * EnsembleExtentReporterNG ros = new EnsembleExtentReporterNG();
	 * ros.getClass(EnsembleExtentReporterNG); Test.log(LogStatus.INFO,"TN used is "
	 * + EnsembleProductInfo.wtn);
	 * //com.aventstack.extentreports.model.Test.log(LogStatus.INFO,"TN used is " +
	 * wtn); }
	 */
}




